def func():
    try:
        i = int(input('Enter a number: '))
        x = 1 / i
    except ZeroDivisionError:
        print("Can't divide by zero!")
        return
    else:
        print('Everything OK')
    finally:
        print('Do this either way')

func()
