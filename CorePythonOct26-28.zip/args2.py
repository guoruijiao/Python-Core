
import sys

for idx, arg in enumerate(sys.argv):
    print("arg %d is %s" % (idx, arg))
