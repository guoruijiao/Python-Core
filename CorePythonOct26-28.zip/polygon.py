class Polygon():
    def __init__(self, num_sides):
        self.num_sides = num_sides
        self.sides = [0 for i in range(num_sides)]

    def __repr__(self):
        return ", ".join([str(i) for i in self.sides])
    
    def inputSides(self):
        self.sides = [float(input("Enter side "+ str(i + 1) + ": "))
                      for i in range(self.num_sides)]
        
    def area(self):
        print("Can't compute area of unknown polygon!")
        raise ValueError

class Triangle(Polygon):
    def __init__(self):
        '''
        use super() to call __init__ in base class and
        be sure we have 3 sides
        '''
        super().__init__(3)
        
    def area(self):
        import math
        a, b, c = self.sides
        'compute semi-perimeter'
        s = sum(self.sides) / 2
        "compute area using Heron's formula"
        area = math.sqrt((s * (s - a) * (s - b) * (s - c)))
        return area

class Square(Polygon):
    def __init__(self):
        super().__init__(4)

    def inputSides(self):
        'only need one side length for a square'
        s = float(input("Enter length of side: "))
        'only need to store one side'
        self.sides = [s]

    def area(self):
        return self.sides[0] ** 2
