with open("/tmp/test.txt", "r") as f1:
    lines = f1.readlines()

with open("/tmp/test2.txt", "w") as f2:
    for line in lines[::-1]:
        f2.write(line)

'''
or

    for line in reversed(lines):
        f2.write(line)
'''

