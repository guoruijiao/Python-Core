s = input('Enter a list of items: ')
list1 = s.split()
list2 = []

for item in list1:
    # Only add items which are not already in list2
    if not item in list2: 
        list2.append(item)

print(' '.join(list2))

