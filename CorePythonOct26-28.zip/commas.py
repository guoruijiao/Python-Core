# Just an example of a function, but no need for this.
# If you want to add commas, you can use a Python 3
# style formatted print like so:
#
# print ("Total cost is: ${:,.2f}".format(num))

def add_commas(num):
    '''
    Add commas to a number. 12345 => 12,345
    '''
    # Convert to a string and reverse it in
    # order to make it easier to work with.
    num = str(num)[::-1]
    commanum = ''
 
    # Loop through the number 3 digits at a
    # time and add a comma. Don't add a comma
    # if there are fewer than 3 digits left.
    for position in range(0, len(num), 3):
        commanum += num[position:position + 3]
        if position + 3 < len(num):
            commanum += ','

    commanum = commanum[::-1]
    return commanum

