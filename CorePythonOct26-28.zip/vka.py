def vka(**args):
    print("args are", args)

    if "blah" in args.keys():
        print("found blah = ", args['blah'])
        
