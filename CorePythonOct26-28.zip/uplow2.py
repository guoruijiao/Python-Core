
s = input("Enter a string: ")
stride = int(input("Enter a stride: "))

up = True
t = ''

for i in range(0, len(s), stride):
    if up:
        t += s[i:i + stride].upper()
 #       up = False
    else:
        t += s[i:i + stride].lower() 
 #       up = True
     up = not up

print(t)
