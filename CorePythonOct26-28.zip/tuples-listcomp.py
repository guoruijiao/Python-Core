words = input("Enter a list of words: ")

'split string into a list of words'
wordlist = words.split()

'use a list comprehension to create a sorted list of tuples (len, word)'
tuples = sorted([(len(word), word) for word in wordlist])

'overwrite wordlist with new list created from second element of each tuple'
wordlist = [w for l, w in tuples]
    
print("sorted by length of word: ", wordlist)

