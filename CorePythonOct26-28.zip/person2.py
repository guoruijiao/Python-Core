
class Person():
    '''A "person" object which has one attribute, name.'''
    
    def __init__(self, name):
        '''This method is essentially a "constructor" which
           initializes a new object. The 'name' attribute of
           the object is set to whatever value is passed in
           when the object is created, e.g.,

           somebody = Person('Donald Duck')
        '''
        self.name = name

    def print_name(self):
        '''This method prints out the name of the Person object.'''
        print('My name is', self.name)

        
