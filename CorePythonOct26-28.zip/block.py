if True:
    x = 'global x' # declare var inside block

print("outside the block, x =", x)

def func():
    print("---> in func")
    x = 'func x' # declare var inside function
    print("x =", x)
    d = locals()
    print("local x =", d['x'])
    d = globals()
    print("global x =", d['x'])
    print("---> leaving func")

func()

print("in main, after func call, x =", x)

def func():
    print("---> inside second func")
    # can access global variables here
    print("x =", x)
    # ...but to change them, we need to bind
    # the name 'x' to the global var instead
    # of a new local var...
    global x
    x = 'new global x'
    print("x =", x)
    print("---> leaving second func, x =", x)

func()
print("in main, after second func call, x =", x)

