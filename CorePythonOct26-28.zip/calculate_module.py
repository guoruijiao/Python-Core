def calculate(operand1, operand2, operator, **kwargs):
    useFloat = False
    
    if kwargs.get('float'):
        operand1 = float(operand1)
        operand2 = float(operand2)
        useFloat = True
    else:
        operand1 = int(operand1)
        operand2 = int(operand2)

    if operator == '+':
        return operand1 + operand2
    elif operator == '-':
        return operand1 - operand2
    elif operator == '*':
        return operand1 * operand2
    elif operator == '/':
        if useFloat:
             return operand1 / operand2
        else:
            return operand1 // operand2

if __name__ == '__main__':
    # this is a test
    print(calculate(2, 4, '+'))
    print(calculate(12, 4, '-'))
