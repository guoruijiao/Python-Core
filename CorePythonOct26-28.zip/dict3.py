mydict = {}

while True:
    cmd = input()
    if cmd == '':
        continue
    if cmd == 'quit': # quit when user says so
        break
    if cmd == '0': # 0 == clear dict
        mydict.clear()
        continue
    if cmd[0] == '-':
        # Don't access cmd[1] unless it exists!
        # --foo = remove *value* 'foo' from dict 
        if len(cmd) > 1 and cmd[1] == '-':
            for key in mydict:
                if mydict[key] == cmd[2:]:
                    del mydict[key]
                    break
            # this else goes with the 'for' loop
            else:
                print('there is no key whose val is', cmd[2:])
        else: # -foo means remove key 'foo' from dict
            if mydict.get(cmd[1:]):
                del mydict[cmd[1:]]
            else:
                print('no such key', cmd[1:])
    else:
        # split key and value and add to dict
        if cmd.count(',') == 1:
            key, val = cmd.split(',')
            mydict[key] = val
        else:
            print("Not sure what you're asking me to do")
        
    print(mydict)
