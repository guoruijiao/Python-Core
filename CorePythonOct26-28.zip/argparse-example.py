import argparse

parser = argparse.ArgumentParser(description='salesƒorce Core Python')

parser.add_argument('-a', action="store_true", default=False)
parser.add_argument('-b', action="store", dest="b")
parser.add_argument('-c', action="store", dest="c", type=int)
parser.add_argument('--version', action='version', version='%(prog)s 1.0')

#args = parser.parse_args(['-a', '-bsomething', '-c', '3'])

'''parse args from command line'''
args = parser.parse_args()

print(args)

if args.a:
    print("-a was passed")
if args.b:
    print("-b", args.b, "was passed")
if args.c:
    print("-c", args.c, "was passed (int)")


