mydict = {}

while True:
    print('''
e) erase dict
a) add item to dict ('key,value')
d) delete item by key
r) delete item by value
q) quit''')

    i = input()
    if i == '': # if nothing entered, try again...
        continue
    if i == 'q':
        break
    if i[0] == 'e': # ...so we can ensure i[0] is valid
        mydict = {} # cf. mydict.clear()
    elif i[0] == 'a':
        'Split input on comma and use results as key and value'
        key, val = i[1:].split(',')
        mydict[key] = val       
    elif i[0] == 'd':
        '''Rest of input line is key, so grab it and delete
        item. Use get() function in case key does not exist'''
        if mydict.get(i[1:]):
            mydict.pop(i[1:])
        else:
            print("no key", i[1:])
    elif i[0] == 'r':
        '''
        Rest of input is val, so grab it and then search
        through dict looking for a key which matches value.
        Remeber mydict.items() is a *view* object, so if we
        modify the dict during the loop, we must break out
        before the loop executes again, and therefore we
        couldn't do this if we wanted to remove *all* items
        whose key matches the value. In that case we would
        put items into a list,...list(mydict.items()) and
        then we could repeatedly modify the dict in the loop.
        '''
        for key, val in mydict.items():
            if val == i[1:]:
                mydict.pop(key)
                break
    print("\n", mydict)

