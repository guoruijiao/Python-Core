
print("Think of a number between 1 and 1000 and I will guess it.")
low = 1
high = 1000

while 1:
  guess = (high + low) / 2
  print("Is your number", guess, "?")
  print("Enter c for correct, l for too low, h for too high:", end=' ')
  answer = input()
  if answer == 'c':
    break
  if answer == 'l':
    low = guess
  elif answer == 'h':
    high = guess
  else:
    print("bad answer")
  

