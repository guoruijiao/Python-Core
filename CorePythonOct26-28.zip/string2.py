s1 = input("Enter a string: ")
s2 = input("Enter another string: ")

#See if lower-cased version of s1 ends with
# lower-cased version of s2.
if s1.lower().endswith(s2.lower()):
    print(s1, "ends with", s2)
    
# ...and vice versa
elif s2.lower().endswith(s1.lower()):
    print(s2, "ends with", s1)
