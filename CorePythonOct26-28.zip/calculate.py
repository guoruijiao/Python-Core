
def calculate(operand1, operand2, operator):
    if operator == '+':
        return operand1 + operand2
    elif operator == '-':
        return operand1 - operand2
    elif operator == '*':
        return operand1 * operand2
    elif operator == '/':
        if float:
             return operand1 / operand2
        else:
            return operand1 // operand2
    elif operator == 'log':
        from math import log
        base = operand2
        try:
            val = log(operand1) / log(base)
        except ZeroDivisionError:
            print("There is no such thing as base 1!")
        except ValueError:
            print("Can't take log(0.0)!")
        else:
            return val

    
