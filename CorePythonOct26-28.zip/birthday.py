'''
Compute probability that in a group of people, two people have the
same birthday.
'''
prob = 1.0

for people in range(2, 51):
    prob *= (366 - people) / 365.0
    print("{0} {1:.1f}%".format(people, 100.0 * (1 - prob)))

