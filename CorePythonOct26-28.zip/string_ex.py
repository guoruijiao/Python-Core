
s = input("Enter a string: ")

for ltr in s:
  print(ltr + ltr, end='')

print()
