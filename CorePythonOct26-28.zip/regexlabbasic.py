import sys
import re

for line in open(sys.argv[1], 'r'):
    if re.search(sys.argv[2], line):
        print(line, end='')

