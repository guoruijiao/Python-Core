class Test:
    public_data = "public data"
    _private_data = "private data"
    __mangled_data = "mangled data"
  
print("in mymodule TWO")
