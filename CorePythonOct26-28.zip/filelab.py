count = {}

filename = input('Enter a filename: ')

for line in open(filename):
    line = line.lower()
    for word in line.split():
        if count.get(word):
            # word in dict, so increment count
            count[word] += 1
        else:
            # word not in dict, so start count at 1
            count[word] = 1

# sort by *value*, not by key
for key in sorted(count, key=count.get):
    print(key, count[key])

    
