words = input("Enter a list of words: ")

wordlist = words.split() # split string into a list of words

tuples = []

for word in wordlist:
  tuples.append((len(word), word))

tuples.sort() # sort() will sort by first element

'''
overwrite the wordlist with a new list created from the second
element of each tuple
'''
wordlist = []
for t in tuples:
    wordlist.append(t[1])

print("sorted by length of word: ", wordlist)
