def sum_digits(x):
    '''
    sum up the digits in x.

    Keep summing up the digits until the result is < 10.
    '''
    sum = 0
    for digit in str(x):
        sum += int(digit)

    '''
    If the sum contains more than 1 digit, call ourself
    recursively to get the job done, otherwise just return
    the sum.
    '''
    if sum > 9:
        return sum_digits(sum)
    return sum

