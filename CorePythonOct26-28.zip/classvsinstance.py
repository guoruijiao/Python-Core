class Test():
    class_var = 'This var is for every instance'

    def __init__(self, val):
        self.instance_var = val

    def __repr__(self):
       return 'instance var = ' + \
              self.instance_var + \
              '\nclass var = ' + \
              self.class_var

