class myclass(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def somefunc(self):
        return self.x + self.y

cl = myclass(1, 2)
print(cl.somefunc())
