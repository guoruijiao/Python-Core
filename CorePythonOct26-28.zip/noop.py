def noop():
    pass

noop()
noop(1)
