def func(x):
    return x+1

print('__name__ ==', __name__)

if __name__ == '__main__':
    if func(4) == 5:
        print('it worked')
