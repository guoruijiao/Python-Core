mylist = []

while True:
    cmd = input()
    if cmd == '': # try again if user hit return
        continue
    if cmd == 'quit':
        break
    if cmd[0] == '-':
        if cmd == '-': # reverse list if input is '-'
            mylist = mylist[::-1]
        else:
            '''User entered '-' followed by one or more words, so split input
            into words, then remove the words one by one from the list.'''
            for word in cmd[1:].split():
                if word in mylist: # can't remove if not in list
                    mylist.remove(word)
                else:
                    print(word, 'not in list!')
    else:
        '''At this point we need to add the word(s) that the user entered.
        So we split the input and use +=.'''
        mylist += cmd.split()
    print(mylist)
