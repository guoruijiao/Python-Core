def sum_digits(x):
    '''
    sum up the digits in x.

    Keep summing up the digits until the result is < 10.

    This time use arithmetic instead of treating the number
    as a string.
    '''
    sum = 0
    while x > 0:
        sum += x % 10
        x //= 10      # same as "x = x // 10"

    '''
    If the sum contains more than 1 digit, call ourself
    recursively to get the job done, otherwise just return
    the sum.
    '''
    if sum > 9:
        return sum_digits(sum)
    return sum



