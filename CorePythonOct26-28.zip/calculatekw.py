
def calculate(operand1, operand2, operator, **kwargs):
    doFloat = False

    if kwargs.get('float') == True:
        operand1 = float(operand1)
        doFloat = True

    if operator == '+':
        return operand1 + operand2
    elif operator == '-':
        return operand1 - operand2
    elif operator == '*':
        return operand1 * operand2
    elif operator == '/':
        if doFloat:
             return operand1 / operand2
        else:
            return operand1 // operand2

