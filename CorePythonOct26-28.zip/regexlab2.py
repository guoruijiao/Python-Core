import sys
import re
import argparse

parser = argparse.ArgumentParser(description='cheesy version of grep')
parser.add_argument('-f', action="store", dest="file", required=True)
parser.add_argument('-p', action="store", dest="pattern", required=True)
parser.add_argument('-c', action="store_true", default=False)
parser.add_argument('--version', action='version', version='%(prog)s (cheesy)')

args = parser.parse_args()

cre = re.compile(args.pattern)

with open(args.file, 'r') as f:
    lines = f.readlines()

lines = [line.strip() for line in lines]

for linenum in range(0, len(lines)):
    if cre.search(lines[linenum]):
        if args.c:
            print("/{}/\n{}\n/{}/\n".format(lines[linenum-1], lines[linenum], lines[linenum+1]))
        else:
            print(lines[linenum])
        
