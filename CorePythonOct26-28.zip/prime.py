for num in range(2, 26): # Check all primes from 2 to 25

    for check in range(2, num): # try to divide in numbers from 2 to num-1
        if num % check == 0: # not prime!
            print(num, 'equals', check, '*', num // check)
            break
    else:                
        print(num, 'is a prime number')

