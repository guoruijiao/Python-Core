
s = input("Enter a string: ")
t = ""

# For each cchhaarraacctteerr in s, add it to the
# new string, t, TWICE.

for c in s:
    t += c + c 

print(t)

