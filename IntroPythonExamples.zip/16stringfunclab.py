s1 = input("Enter a string: ")
s2 = input("Enter another string: ")

if s1.lower().endswith(s2.lower()):
    print(s1, "ends with", s2)
elif s2.lower().endswith(s1.lower()):
    print(s2, "ends with", s1)

