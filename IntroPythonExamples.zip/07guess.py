my_number = 37
print("Enter your guess: ", end='')
guess = int(input())

if guess > my_number:
    print("Guess was too high")
elif guess < my_number:
    print("Guess was too low")
else:
    print("You got it!")
