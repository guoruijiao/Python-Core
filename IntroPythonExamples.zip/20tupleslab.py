words = input("Enter a list of words: ")

'split string into a list of words'
wordlist = words.split()

tuples = []

for word in wordlist:
    tuples.append((len(word), word))

'sort the list of tuples, which will sort by first element'
tuples.sort()

'''
overwrite the wordlist with a new list created from the second
element of each tuple
'''
wordlist = [tuple[1] for tuple in tuples]

print("sorted by length of word: ", wordlist)
