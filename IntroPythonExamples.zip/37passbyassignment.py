def func(x):
    # x can be changed if it's a reference...
    x.append('new')
    # ...but if it's rebound, a local copy has 
    # now been created, and that local copy won't
    # be passed back to the caller.
    x = [4, 5, 6]
    print(x)

l = [1, 2, 3]
func(l)
print(l)
