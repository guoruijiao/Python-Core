
s = input("Enter a string: ")
t = ""

for c in s:
    t += c + c

print(t)



