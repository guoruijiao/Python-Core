# repr() is a builtin Python function which returns the
# internal represenation of an object. We can use repr()
# to print out a string with its surrounding quotes.

s = ' Now is the time      '
print(repr(s.strip()))
print(repr(s))
s = '.' + s.strip() + '...'
print(repr(s))
print(repr(s.strip('.')))
