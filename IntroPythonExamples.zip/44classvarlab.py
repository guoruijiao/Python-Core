class Test():
    # this is a class var, shared by all instances
    class_var = 'This var is shared by every instance'
    
    def __init__(self, val):
        self.instance_var = val

    def __repr__(self):
        return 'instance var = ' + \
               self.instance_var + \
               '\nclass var = '  + \
               self.class_var

a = Test('a')
b = Test('b')
print(a)
print(b)
a.instance_var = 'no longer a'
print(a)
print(b)
Test.class_var = 'Presto change-o!'
print(a)
print(b)
