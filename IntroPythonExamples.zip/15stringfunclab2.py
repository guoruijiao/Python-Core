s = input("Enter a string: ")
stride = int(input("Enter a stride: "))
t = ''

up = True

for i in range(0, len(s), stride):
    if up:
        t += s[i:i + stride].upper()
    else:
        t += s[i:i + stride].lower() 
    # Booleans are either True or False. The 'not' operator will
    # change the sense of a Boolean–if it's True it will become
    # False, and vice versa.
    up = not up

print(t)
