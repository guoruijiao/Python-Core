d = { 'foo': 'bar', '1': '2' }
print(d['foo'])
# print(d['foot'])
print(d.get('foo'))
print(d.get('foot'))
print(d.setdefault('foot', 23))
print(d)
