
#!/usr/bin/env python3
def func():
    x = 'local to func()'
    print('entering func, x =', x)

    def funcinfunc():
        print('in funcinfunc(), x =', x)
        global x
        x = 'ecks'

    def func2infunc():
        print('in func2infunc(), x =', x)
        nonlocal x
        x += ' and modified by nested function'

    funcinfunc()
    func2infunc()
    print('leaving func, x =', x)

x = 'global x'
print('global x =', x)
func()
print('global x =', x)
