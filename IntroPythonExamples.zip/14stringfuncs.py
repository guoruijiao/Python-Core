# repr() is a builtin Python function which returns the
# internal represenation of an object. We can use repr()
# to print out a string with its surrounding quotes.

s = 'now IS the time'
print(repr(s.capitalize()))
print(repr(s.title()))
print(repr(s.upper()))
print(repr(s.lower()))
print(repr(s.swapcase()))
print(repr(s.replace('the', 'not the')))
print(repr(s.replace('t', 'T')))
