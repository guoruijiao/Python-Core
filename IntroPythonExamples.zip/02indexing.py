alphabet = 'abcdefghijklmnopqrstuvwxyz'

for index in 0, 25, -1, -26:
    print("alphabet[%d] = '%s'" % (index, alphabet[index]))
