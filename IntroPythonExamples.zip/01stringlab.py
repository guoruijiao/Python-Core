a, b, o, p = 'b', 'a', 'p', 'o'
print(o + p + o)
print(a * 3 + b)
print(a + p * 2 + 'k' * 2 + 'e' * 2  + o + 'er')
