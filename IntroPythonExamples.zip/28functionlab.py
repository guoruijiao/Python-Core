
def rounder(amount, inc):
    '''
    Return amount rounded UP to nearest
    increment.
        ...$1.89 becomes $2.00
        ...but $1.XX/$1.XX/$1.XX, where
           XX is a multiple of the increment
           remain unchanged.
    '''
    dollars = int(amount)
    cents = round((amount - dollars) * 100)
    coins = cents // inc
    if cents % inc:
        coins += 1
    amount = dollars + (inc / 100) * coins

    return amount


