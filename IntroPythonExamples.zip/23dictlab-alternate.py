mydict = {}

while True:
    print('''
e) erase dict
a) add item to dict ('key,value')
d) delete item by key
r) delete item by value''')
    i = input()
    if i == '': # if nothing entered, try again...
        continue
    if i[0] == 'e': # ...so we can ensure i[0] is valid
        mydict = {}
    elif i[0] == 'a':
        'Split input on comma and use results as key and value'
        key, val = i[1:].split(',')
        mydict[key] = val       
    elif i[0] == 'd':
        '''Rest of input line is key, so grab it and delete
        item. Use get() function in case key does not exist'''
        if mydict.get(i[1:]):
            del mydict[i[1:]]
        else:
            print("no key", i[1:])
    elif i[0] == 'r':
        '''Rest of input is val, so grab it and then remove
        the item whose value is val'''
        val = i[1:]
        print('deleting', val)
        mydict = { key:mydict[key] for key in mydict
                       if mydict[key] != val }

    print("\n", mydict)

