import string

filename = input('Enter a filename: ')
ex = set(string.punctuation)
count = {}

for line in open(filename):
    line = line.lower()
    line = ''.join([ch for ch in line if ch not in ex])
    for word in line.split():
        count[word] = count.get(word, 0) + 1

for key in sorted(count, key=count.get):
    print(key, count[key])


    
