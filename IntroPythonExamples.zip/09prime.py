import math

for num in range(2, 26):
   for i in range(2, round(math.sqrt(num)) + 1):
      if num % i == 0:      
         j = num / i
         print('%d equals %d * %d' % (num, i, j))
         break
   else:                
      print(num, 'is a prime number')
