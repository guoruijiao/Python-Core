name = input('Enter your name: ')
print('You entered', name)
