s = input("Enter a string: ")
stride = int(input("Enter a stride: "))
t = ''

up = True

for i in range(0, len(s), stride):
    if up:
        t += s[i:i + stride].upper()
        up = False
    else:
        t += s[i:i + stride].lower()
        up = True

print(t)


