x = 1

if x == 1:
    print('Hey, x is 1')
else:
    print('x is something other than 1')
