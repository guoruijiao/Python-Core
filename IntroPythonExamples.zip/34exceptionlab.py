def calculate(operand1, operand2, operator):
    if operator == '+':
        return operand1 + operand2
    elif operator == '-':
        return operand1 - operand2
    elif operator == '*':
        return operand1 * operand2
    else:
        try:
            return operand1 / operand2
        except ZeroDivisionError:
            print("No divide by zero!")
            return 0
