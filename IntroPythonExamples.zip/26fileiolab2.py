count = {}

filename = input('Enter a filename: ')

for line in open(filename):
    line = line.lower()
    for word in line.split():
        if count.get(word):
            count[word] += 1
        else:
            count[word] = 1

for key in sorted(count, key=count.get):
    print(key, count[key])

    
