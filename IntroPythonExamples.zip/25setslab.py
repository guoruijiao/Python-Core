d = { "boys": set(), "girls": set() }

while True:
    print('''
b) Add a boy name
g) Add a girl name
u) Print union
i) Print intersection
m) Check for membership
q) Quit''')
    i = input()
    if i == '':
        continuec
    if i[0] == 'q':
        break
    elif i[0] == 'b':
        d["boys"].add(i[1:]) # add rest of input line
        
    elif i[0] == 'g':
        d["girls"].add(i[1:]) # add rest of input line
    elif i[0] == 'u':
        print(d["boys"] | d["girls"]) # union
    elif i[0] == 'i':
        print(d["boys"] & d["girls"]) # intersection
    elif i[0] == 'm': # membership
        for l in d.keys():
            print(i[1:], end=' ')
            if not i[1:] in d[l]:
                print("NOT", end= ' ')
            print("in", l)
            
    print("\nGirls:", d["girls"])
    print("Boys:", d["boys"])

