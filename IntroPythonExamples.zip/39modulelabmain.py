#!/usr/bin/env python3

from calculate_module import calculate

if __name__ == '__main__':
    import sys
    print(calculate(sys.argv[1], sys.argv[2], sys.argv[3]))

