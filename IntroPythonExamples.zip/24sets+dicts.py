movies = {
    'Die Hard': { 'Bruce Willis', 'Alan Rickman', 'Bonnie Bedelia' },
    'The Sixth Sense': { 'Donnie Wahlberg', 'Toni Collette', 'Bruce Willis' }, 
    'Hunt for Red October': { 'Sean Connery', 'Alec Baldwin' },
    'The Highlander': { 'Christopher Lambert', 'Sean Connery' },
    '16 Blocks': { 'Bruce Willis', 'Yasiin Bey', 'David Morse' },
}

for title, stars in movies.items():
    if 'Bruce Willis' in stars:
        print(title)

print()

for title, stars in movies.items():
    if stars & {'Alan Rickman', 'Sean Connery'}:
        print(title)
