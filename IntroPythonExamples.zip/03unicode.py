#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Try running this directly, then try running it as
#
#	python2 03unicode.py
#

s = 'café'
print(s[3])
cost = '€300'
print(cost[0])
