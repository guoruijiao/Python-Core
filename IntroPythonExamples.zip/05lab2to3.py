s = raw_input('Enter a string: ')
print 'You entered', s
