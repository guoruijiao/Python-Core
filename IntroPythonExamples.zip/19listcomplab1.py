sleeves = ['short', 'long']
sizes = ['S', 'M', 'L']
colors = ['black', 'white']

tshirts = [[size, color, sleeve] for size in sizes
                                 for color in colors
                                 for sleeve in sleeves]

print(tshirts)
