
'''A list of lists. Only using lists[1] and lists[2]
so that list index matches what user calls it.'''
lists = [[], [], []]

while True:
    print('''
s) Show both lists
a) Add an item to a list
i) Remove an item from a list by index
v) Remove an item from a list by value
r) Reverse a list
e) Check for list equality
q) Quit''')

    choice = input()

    if choice == '': # try again if user types nothing
        continue
    if choice == 'q':
        break
    if choice == 's':
        for i in range(1, 3):
            print('\nList', i, ':\n', lists[i])
        print('\n')
        
    elif choice[0] == 'e':
        for i in range(1, 3):
            print('\nlist', i, lists[i])
            
        print('\nComparing the two lists...', end='')
        if sorted(lists[1]) != sorted(lists[2]):
            print('NOT ', end='')
        print('equal\n')
    else:
        '''all other commands need a list number so
        we grab it once and store it in num'''
        num = int(choice[1])
        if choice[0] == 'a':
            lists[num].append(choice[2:])
        elif choice[0] == 'i':
            lists[num].pop(int(choice[2:]))
        elif choice[0] == 'v':
            lists[num].remove(choice[2:])
        elif choice[0] == 'r':
            lists[num] = lists[num][::-1]
                            
