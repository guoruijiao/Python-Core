d = {} # empty dict
d = { 'X': 10, 'V': 5, 'I': 1 } # initialized
print(d)
d['L'] = 50
print(d)
for numeral in d:
    print(numeral, end=' ')
print()
