import sys
import re

if len(sys.argv) != 3:
  print('oops, need 2 args')
  sys.exit(1)

cre = re.compile(sys.argv[2])

with open(sys.argv[1], 'r') as f:
    lines = f.readlines()

lines = [line.strip() for line in lines]

for linenum in range(0, len(lines)):
    if cre.search(lines[linenum]):
        print("/{}/\n{}\n/{}/\n".format(lines[linenum-1], lines[linenum], lines[linenum+1]))

        

