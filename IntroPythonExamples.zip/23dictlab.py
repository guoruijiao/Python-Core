mydict = {}

while True:
    print('''
e) erase dict
a) add item to dict ('key,value')
d) delete item by key
r) delete item by value''')
    i = input()
    if i == '': # if nothing entered, try again...
        continue
    if i[0] == 'e': # ...so we can ensure i[0] is valid
        mydict = {} # cf. mydict.clear()
    elif i[0] == 'a':
        'Split input on comma and use results as key and value'
        key, val = i[1:].split(',')
        mydict[key] = val       
    elif i[0] == 'd':
        '''Rest of input line is key, so grab it and delete
        item. Use get() function in case key does not exist'''
        if mydict.get(i[1:]):
            mydict.pop(i[1:])
        else:
            print("no key", i[1:])
    elif i[0] == 'r':
        '''Rest of input is val, so grab it and then search
        through dict looking for a key which matches value.
        Remeber mydict.items() is a *view* object, so we can't
        modify the dict during the loop. Other way to do it
        is to put items into a list,...list(mydict.items())
        and then it's OK to modify the dict in a loop.'''
        found = False
        for key, val in mydict.items():
            if val == i[1:]:
                found = True
                break
        '''If found is True then it means we found key whose
        value is that which we want to delete.'''
        if found:
            mydict.pop(key)

    print("\n", mydict)

