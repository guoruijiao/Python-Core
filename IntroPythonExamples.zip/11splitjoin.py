print("Now is the time".split())
print("eggs, bread, milk, yogurt".split(', '))
print(''.join(['anti', 'dis', 'establish', 'men', 'tarian', 'ism']))
print(', '.join(['Anne', 'Robert', 'Nancy']))
