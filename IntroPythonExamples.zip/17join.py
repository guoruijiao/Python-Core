stooges = ['Larry', 'Moe', 'Curley', 'Shemp']
joined = ', '.join(stooges)
print(joined)
unjoined = joined.split(', ')
print(unjoined)
print(stooges == unjoined)
