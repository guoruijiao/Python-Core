class Duck():
    '''getters/setters example using decorators'''
    def __init__(self, input_name):
        self.__name = input_name

    @property
    def name(self): 
        '''getter for name attribute'''
        print('inside the getter')
        return self.__name

    @name.setter
    def name(self, input_name):
        '''setter for name attribute'''
        print('inside the setter')
        self.__name = input_name

        

